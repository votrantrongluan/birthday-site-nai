
// You can add interactive JavaScript here
console.log("Happy Birthday site loaded!");
